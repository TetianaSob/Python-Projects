Django user registration and login with form validation

Registration / Login
------
![index](https://i.imgur.com/PuXZnKW.png)

Success
------
![success](https://i.imgur.com/7QYAYor.png)
